﻿using eauction.Models.Request;
using eauction.Services.Buyer;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eauction.Controllers
{
    [Route("v1/buyer")]
    public class BuyerController : Controller
    {

        private readonly IBuyerService _buyerService;

        public BuyerController(IBuyerService buyerService)
        {
            _buyerService = buyerService;
        }
        [HttpGet("getbuyer")]
        public IActionResult Get()
        {
            var resp = "success buyer";
            return Ok(resp);
        }

        [HttpPost("place-bid")]
        public IActionResult PlaceBid(CreateBuyerBid bid)
        {
            var resp = _buyerService.PlaceBid(bid);
            return Ok(resp);
        }

        [HttpPost("update-bid")]
        public IActionResult UpdateBid(UpdateBidRequest newBid)
        {
            _buyerService.UpdateBid(newBid);
            return Ok("Successfully Updated..!");
        }
    }
}
