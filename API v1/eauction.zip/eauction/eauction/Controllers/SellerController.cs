﻿using eauction.DataSource;
using eauction.Services.Seller;
using EAuction.API.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eauction.Controllers
{
    [Route("v1/seller")]
    public class SellerController : Controller
    {
        private readonly ISellerService _sellerService;

        public SellerController(ISellerService sellerService)
        {
            _sellerService = sellerService;
        }

        [HttpGet("getseller")]
        public IActionResult Get()
        {
            var resp = "success seller";
            TestData.LoadProducuts();
            return Ok(resp);
        }

        [HttpGet("getproducts")]
        public IActionResult GetProducts()
        {
            var resp = _sellerService.GetProducts();
            return Ok(resp);
        }

        [HttpGet("getdbproducts")]
        public IActionResult GetDBProducts()
        {
            var resp_task = _sellerService.GetDBAvailableProducts();
            resp_task.Wait();


            return Ok(resp_task.Result);
        }

        [HttpGet("get-product-seller")]
        public IActionResult GetProductsDetails()
        {
            var resp = _sellerService.GetProducts();
            return Ok(resp);
        }

        [HttpGet("show-bids")]
        public IActionResult GetProductDetails([FromBody] int productId)
        {
            var resp = _sellerService.GetProductBidsDetails(productId);
            //resp.Wait();
            return Ok(resp);
        }

        [HttpPost("add-product")]
        public IActionResult AddProduct([FromBody] CreateProduct product)
        {
            var resp = _sellerService.AddProduct(product);
            return Ok(resp);
        }

        [HttpDelete("delete")]
        public IActionResult DeleteProduct(int productId)
        {
            _sellerService.DeleteProduct(productId);
            return Ok("Deleted Successfully!");
        }
    }
}
