﻿using eauction.Models;
using eauction.Models.Response;
using EAuction.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eauction.Services.Seller
{
    public interface ISellerService
    {
        Product AddProduct(CreateProduct product);

        void DeleteProduct(int productid);

        List<AvailableProducts> GetProducts();

        ProductBids GetProductDetails(int productid);

        Task<List<AvailableProducts>> GetDBAvailableProducts();

        Task<ProductBids> GetDBProductDetails(int productid);

        ProductBids GetProductBidsDetails(int productid);
    }
}
