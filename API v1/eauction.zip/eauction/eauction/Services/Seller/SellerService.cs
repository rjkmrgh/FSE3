﻿using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using eauction.DataSource;
using eauction.Models;
using eauction.Models.Request;
using eauction.Models.Response;
using EAuction.API.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace eauction.Services.Seller
{
    public class SellerService : ISellerService
    {
        private Products ProductDetails { get; set; }
        public IDynamoDBContext _dynamoDBContext { get; }

        public SellerService(IDynamoDBContext dynamoDBContext)
        {
            _dynamoDBContext = dynamoDBContext;
        }
        
        public Product AddProduct(CreateProduct product)
        {
            throw new NotImplementedException();
        }

        public void DeleteProduct(int productid)
        {
            try
            {
                TestData.DelProducut(productid);
            }
            catch (Exception e)
            {

                throw e;
            }
        }

        public ProductBids GetProductDetails(int productid)
        {
            throw new NotImplementedException();
        }

        public List<AvailableProducts> GetProducts()
        {
            List<AvailableProducts> response = new List<AvailableProducts>();
            
            try
            {
                var resp = TestData.GetProducuts();
                foreach (var item in resp)
                {
                    response.Add(new AvailableProducts()
                    {
                        ProductId = item.ProductId,
                        ProductName = item.ProductName
                    });
                }
                
            }
            catch (Exception e)
            {

                throw ;
            }
            return response;
        }

        public ProductBids GetProductBidsDetails(int productid)
        {
            ProductBids pb = new ProductBids();

            var pTask = GetDBProductDetails(productid);

            foreach (var item in pTask.Result)
            {
                pb.ProductName = item.ProductName;
                pb.ShortDescription = item.ShortDescription;
                pb.LongDescription = item.LongDescription;
                pb.Category = item.Category;
                pb.StartingPrice = item.StartingPrice;
                pb.BidEndDate = item.BidEndDate;
            }

            return pb;
        }
        public async Task<List<AvailableProducts>> GetDBAvailableProducts()
        {
            List<AvailableProducts> response = new List<AvailableProducts>();
            
            try
            {
                var conditions = new List<ScanCondition>();
                var resp = await _dynamoDBContext.ScanAsync<Product>(conditions).GetRemainingAsync();
                foreach (var item in resp)
                {
                    response.Add(new AvailableProducts()
                    {
                        ProductId = item.ProductId,
                        ProductName = item.ProductName
                    });
                }
            }
            catch (Exception e)
            {
                throw;
            }
            return response;
        }

        public async Task<List<Product>> GetDBProductDetails(int productid)
        {
            List<Product> response = null;

            try
            {
                var conditions = new List<ScanCondition>();
                conditions.Add(new ScanCondition("ProductId", ScanOperator.Equal, productid));
                response = await _dynamoDBContext.ScanAsync<Product>(conditions).GetRemainingAsync();
                 
            }
            catch (Exception e)
            {
                throw;
            }
            return response;
        }

        public async Task<List<Bids>> GetDBProductBidsDetails(int productid)
        {
            List<Product> response = null;

            try
            {
                var conditions = new List<ScanCondition>();
                conditions.Add(new ScanCondition("ProductId", ScanOperator.Equal, productid));
                response = await _dynamoDBContext.ScanAsync<ProductBids>(conditions).GetRemainingAsync();

            }
            catch (Exception e)
            {
                throw;
            }
            return response;
        }
        Task<ProductBids> ISellerService.GetDBProductDetails(int productid)
        {
            throw new NotImplementedException();
        }
    }
}
