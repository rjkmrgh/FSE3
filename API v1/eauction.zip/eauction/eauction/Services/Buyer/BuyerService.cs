﻿using eauction.Models;
using eauction.Models.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eauction.Services.Buyer
{
    public class BuyerService : IBuyerService
    {
        public BuyerBids PlaceBid(CreateBuyerBid bid)
        {
            throw new NotImplementedException();
        }

        public void UpdateBid(UpdateBidRequest bids)
        {
            throw new NotImplementedException();
        }
    }
}
