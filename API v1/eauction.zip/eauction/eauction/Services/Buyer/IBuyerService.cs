﻿using eauction.Models;
using eauction.Models.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eauction.Services.Buyer
{
    public interface IBuyerService
    {
        BuyerBids PlaceBid(CreateBuyerBid bid);

        void UpdateBid(UpdateBidRequest bid);
    }
}
