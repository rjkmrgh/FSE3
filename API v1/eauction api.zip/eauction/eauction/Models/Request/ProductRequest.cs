﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eauction.Models.Request
{
    public class ProductRequest
    {
        public string ProductId { get; set; }
    }
}
